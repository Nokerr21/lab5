def booth_function(x):
    #Funkcja zwracająca
    return pow(x[0] + 2 * x[1] - 7, 2) + pow(2 * x[0] + x[1] - 5, 2)