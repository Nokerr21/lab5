import numpy as np
from autograd import grad

import plot_utils
import booth_utils
from cec2017.functions import f1
from cec2017.functions import f2
from cec2017.functions import f3


def solve_booth_function(upper_bound, DIMENSIONALITY, beta):
    #losowanie punktu startowego
    x = np.random.uniform(-upper_bound, upper_bound, size=DIMENSIONALITY)
    # beta = 0.01
    gradient_descent(upper_bound, x, booth_utils.booth_function, beta) #Wywołanie funkcji obliczającej minimum funkcji za pomocą metody najszybszego spadku


def solve_f1(upper_bound, DIMENSIONALITY, beta):
    x = np.random.uniform(-upper_bound, upper_bound, size=DIMENSIONALITY)
    # beta = 0.000000001
    gradient_descent(upper_bound, x, f1, beta)


def solve_f2(upper_bound, DIMENSIONALITY, beta):
    x = np.random.uniform(-upper_bound, upper_bound, size=DIMENSIONALITY)
    # beta = 0.0000000000000001
    gradient_descent(upper_bound, x, f2, beta)


def solve_f3(upper_bound, DIMENSIONALITY, beta):
    x = np.random.uniform(-upper_bound, upper_bound, size=DIMENSIONALITY)
    # beta = 0.000001
    gradient_descent(upper_bound, x, f3, beta)


def gradient_descent(upper_bound, starting_point, function, beta):
    plot_utils.prepare_plot(function, upper_bound) #Przygotowanie wykresu
    current_cords = starting_point
    iterations = 0
    iterations_limit = 40000
    should_run = True
    while should_run:
        #Obliczenie gradientu
        if iterations >= iterations_limit:
            should_run = False
        iterations += 1
        grad_fct = grad(function)
        plot_utils.add_point(current_cords[0], current_cords[1], upper_bound) #Dodanie aktualnego punktu do wykresu
        gradient = grad_fct(current_cords)
        old_cords = current_cords
        current_cords = current_cords - beta * gradient
        for i in range(len(current_cords)): #Ograniczenie poprzez rzutowanie
            if current_cords[i] > upper_bound:
                current_cords[i] = upper_bound
            if current_cords[i] < -upper_bound:
                current_cords[i] = -upper_bound
        plot_utils.add_arrow(old_cords[0], old_cords[1], current_cords[0], current_cords[1], upper_bound) #Dodanie strzałki na wykresie
        # print("Value: ", function(current_cords))
        if function(old_cords) - function(current_cords) < 0.0000001: #Sprawdzenie, czy obliczony punkt jest bardzo bliski minimum funkcji
            should_run = False
    print("Found for: ", current_cords)
    print("Value: ", function(current_cords))
    # print("Starting point: ", starting_point)
    print("Iterations: ", iterations)
    print()
    plot_utils.show_plot() #Wyświetlenie wykresu
