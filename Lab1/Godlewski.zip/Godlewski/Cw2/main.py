import logic

if __name__ == "__main__":
    #Wywołanie funkcji odpowiedzialnych za wyznaczanie minimum funkcji
    beta = 0.01
    print(beta)
    UPPER_BOUND = 10
    DIMENSIONALITY = 2

    print("Booth")
    logic.solve_booth_function(UPPER_BOUND, DIMENSIONALITY, beta)

    UPPER_BOUND = 100
    DIMENSIONALITY = 10
    beta = 0.000000000001
    print("f1")
    logic.solve_f1(UPPER_BOUND, DIMENSIONALITY, beta)

    print("f2")
    logic.solve_f2(UPPER_BOUND, DIMENSIONALITY, beta)

    print("f3")
    logic.solve_f3(UPPER_BOUND, DIMENSIONALITY, beta)

