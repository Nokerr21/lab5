import matplotlib.pyplot as plt
import numpy as np


def prepare_plot(function, UPPER_BOUND):
    PLOT_STEP = 0.1

    x_arr = np.arange(-UPPER_BOUND, UPPER_BOUND, PLOT_STEP)
    y_arr = np.arange(-UPPER_BOUND, UPPER_BOUND, PLOT_STEP)
    X, Y = np.meshgrid(x_arr, y_arr)
    Z = np.empty(X.shape)

    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            Z[i, j] = function(np.array([X[i, j], Y[i, j]]))

    plt.contour(X, Y, Z, 300, zorder=0)


def add_point(x1, x2, UPPER_BOUND):
    marker_size = 3
    if UPPER_BOUND == 10:
        marker_size = 2
    plt.plot(x1, x2, marker='o', markersize=marker_size, color="red")


def add_arrow(x1_old, x2_old, x1_new, x2_new, UPPER_BOUND):
    arrow_size = 3
    if UPPER_BOUND == 10:
        arrow_size = 0.3
    plt.arrow(x1_old, x2_old, x1_new - x1_old, x2_new - x2_old, head_width=arrow_size, head_length=arrow_size, fc='k',
              ec='k')


def show_plot():
    plt.show()
