import numpy as np

def generate_items(min_value, max_value, n):
    # Generuje losowe wagi i wartości dla przedmiotów oraz oblicza maksymalną wagę plecaka.
    # items_weight = np.array([8, 3, 5, 2])  # masa przedmiotów
    # items_price = np.array([16, 8, 9, 6]) #wartość przedmiotów

    items_weight = np.random.randint(min_value, max_value, size=n) # masa przedmiotów
    items_price = np.random.randint(min_value, max_value, size=n) #wartość przedmiotów
    calculated_max_backpack_weight = np.sum(items_weight) / 2

    # Połączenie wag i wartości w listę par w formacie [[m1, p1], [m2, p2], [m3, p3], ...]
    return calculated_max_backpack_weight, np.column_stack((items_weight, items_price))


def generate_all_possible_subsets(items):
    # Generuje wszystkie możliwe podzbiory przedmiotów.
    result = [[]]
    for item in items:
        new_result_subset = [result_subset + [item] for result_subset in result] #Dla każdego elementu listy result i items stwórz kombinację tych elementów
        result.extend(new_result_subset)
    return result


def solve_bruteforce(items, max_backpack_weight):
    # Rozwiązuje problem plecakowy bruteforce, sprawdzając wszystkie możliwe kombinacje.
    best_weight = 0
    best_price = 0
    items_sets = generate_all_possible_subsets(items)
    result_items = []

    if len(items_sets) > 0 and max_backpack_weight > 0: #Sprawdzenie, czy są dotępne przemdioty oraz czy plecak ma pojemność > 0
        for item_set in items_sets:
            item_set_weight = 0
            item_set_price = 0
            for set_element in item_set:
                item_set_weight += set_element[0]
                item_set_price += set_element[1]
            if item_set_price > best_price and item_set_weight <= max_backpack_weight: #Sprawdzenie, czy obecna kombinacja przedmiotów jest droższa od najlepszego dotychczas oraz czy spełania warunki wagowe
                best_price = item_set_price
                best_weight = item_set_weight
                result_items = item_set
            elif item_set_price == best_price and item_set_weight < best_weight: #Sprawdzenie, czy obecna kombinacja przedmiotów jest tak samo droga najlepsza dotychczas oraz czy jest lżejsza od najlepszej dotychczas
                best_price = item_set_price
                best_weight = item_set_weight
                result_items = item_set

    return result_items, [best_weight, best_price]


def solve_heuristic(items, max_backpack_weight):
    # Rozwiązuje problem plecakowy heurystycznie, sortując przedmioty według stosunku wartości do wagi.
    min_item_weight = min(items, key=lambda x: x[0])[0] #Znalezienie wagi najlżejszego przedmiotu w zbiorze
    items = sorted(items, key=lambda x: x[1] / x[0], reverse=True) #Posortowanie zbioru przedmiotów
    result_items_price = 0
    result_items_weight = 0
    result_items = []
    # Wybiera przedmioty o największym stosunku wartości do wagi, dopóki nie przekroczy maksymalnej wagi plecaka.
    for item in items:
        if item[0] + result_items_weight <= max_backpack_weight: #Sprawdzenie czy przedmiot spełnia warunek masy, żeby zostac dodanym do plecaka
            result_items_price += item[1]
            result_items_weight += item[0]
            result_items.append(item)
        #     TODO zmienic warunek
        elif abs(max_backpack_weight - result_items_weight) < min_item_weight:
            break

    return result_items, [result_items_weight, result_items_price]






