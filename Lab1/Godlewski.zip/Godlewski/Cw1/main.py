import time
import logic

if __name__ == "__main__":
    MAX_GENERATED_VALUE = 100
    MIN_GENERATED_VALUE = 1
    NUMBER_OF_ELEMENTS = 20
    max_backpack_weight, start_items = logic.generate_items(MIN_GENERATED_VALUE, MAX_GENERATED_VALUE, NUMBER_OF_ELEMENTS)
    print("Maksymalna waga przedmiotów", max_backpack_weight)

    # Metoda przeglądu wyczerpującego
    start1 = time.process_time()
    result_items_bruteforce, result_bruteforce = logic.solve_bruteforce(start_items, max_backpack_weight)
    end1 = time.process_time()
    total = end1 - start1
    print("Czas wykonywania metody przeglądu wyczerpującego", "{0:02f}s".format(total))
    print("Wynik metody przeglądu wyczerpującego", result_bruteforce)
    print("Przedmioty użyte w rozwiązaniu", result_items_bruteforce)

    print("")

    # Heurystyka
    start2 = time.process_time()
    result_items_heuristic, result_heuristic = logic.solve_heuristic(start_items, max_backpack_weight)
    end2 = time.process_time()
    total = end2 - start2
    print("Czas wykonywania za pomocą heurystyki", "{0:02f}s".format(total))
    print("Wynik heurystyki", result_heuristic)
    print("Przedmioty użyte w rozwiązaniu", result_items_heuristic)
    print("")
    print("")
